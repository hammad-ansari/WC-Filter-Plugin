<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://thewebtechs.com
 * @since      1.0.0
 *
 * @package    Wc_Filter
 * @subpackage Wc_Filter/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wc_Filter
 * @subpackage Wc_Filter/public
 * @author     The Web Techs <thewebtech8765@gmail.com>
 */
class Wc_Filter_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Filter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Filter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wc-filter-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Filter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Filter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-filter-public.js', array( 'jquery' ), $this->version, false );

	}
	public function debug($i){
		echo '<pre>';
		print_r($i);
		echo '</pre>';
	}
	public function wc_filter_form(){

		$brand_terms = get_terms( 'pa_marka' , array('hide_empty' => false) );
		$year_terms = get_terms( 'pa_yil' , array('hide_empty' => true, 'order' => 'DESC') );

?>
<style>
	.ua-wc-filter #wc-filter-form {
		width: 100%;
		max-width: 1000px;
		margin: 10px auto 0px auto;
		transition-delay: 300ms;
		transition: all 300ms ease-in-out;
	}
	.ua-wc-filter form{
		gap: 15px;
		margin-bottom: 0px;
		transition-delay: 300ms;
		transition: all 300ms ease-in-out;
	}
	.ua-wc-filter select,
	.ua-wc-filter button{
		margin: 0px;
		padding: 18px 15px;
		height: auto;
		transition: all 200ms ease-in-out;
		text-transform: capitalize;
	}
	.ua-wc-filter button{
		width: 100%;
		color: #fff;
	}
	.stuck .ua-wc-filter #wc-filter-form{
		max-width: 100%;
	}
	.stuck .ua-wc-filter #wc-filter-form{
		margin: 10px 0px;
	}
	.stuck .ua-wc-filter select,
	.stuck .ua-wc-filter button{
		padding: 10px 15px;
	}
	.ua-wc-filter button:hover{
		background-color: #ab1818!important;
	}
	.wc-mobile {
		width: 100%;
		margin: 10px 0px;
	}
	.wc-filters-button{
		display: none;
		background-color: #f51d1d;
	}
	@media(min-width: 600px){
		.wc-mobile-toggler{
			display: block!important;
		}
	}
	@media(max-width: 600px){
		.ua-wc-filter form {
			gap: 0px!important;
		}
/* 		.wc-filters-button{
			display: block;
		} */
		.wc-mobile .form-inline{
			flex-wrap: wrap;
		}
		.ua-wc-filter select{
			width: calc( 100% / 3 );
			margin-bottom: 10px;
			font-size: 13px;
		}
		.ua-wc-filter select{
			padding: 10px 5px!important;
			height: auto!important;
		}
		.ua-wc-filter button,
		.stuck .ua-wc-filter button{
			padding: 0px;
		}
/* 		.wc-mobile-toggler{
			display: none;
		} */
	}
</style>
<?php

		if(isset($_GET['ua-submit'])){
			$his_brands = $_GET['his_brand'];
			$his_years = $_GET['wc_filter_years'];
			$his_models = $_GET['wc_filter_models'];
		}
		else{
			$his_brands = get_option('wc_brand_text');
			$his_years = get_option('wc_year_text');
			$his_models = get_option('wc_model_text');
		}

?>
<div class="container header-bottom ua-wc-filter">

	<div class='wc-mobile'>

		<button class='wc-filters-button'><?= get_option('wc_filter_mb_text')?></button>
		<div class='wc-mobile-toggler'>
			<form class="form-inline" id="wc-filter-form" action="<?php echo get_permalink( woocommerce_get_page_id( 'shop' ) ) ?>" method="GET">
				<input type='hidden' name='his_brand' value=''>
				<select name="wc_filter_brands" id="wc-filter-brands">
					<option value="<?= esc_html_e($his_brands) ?>"><?= esc_html_e($his_brands, 'wc-filter') ?></option>
					<?php foreach($brand_terms as $key => $brands){ ?>
					<option value='<?= $brands->slug ?>' data-name='<?= $brands->name ?>' ><?= $brands->name ?></option>
					<?php } ?>

				</select>

				<select name="wc_filter_years" id="wc-filter-years" disabled>
					<option value="<?= esc_html_e($his_years) ?>"><?= esc_html_e($his_years, "wc-filter") ?></option>
				</select>
				<select name="wc_filter_models" id="wc-filter-models" disabled>
					<option value="<?= esc_html_e($his_models) ?>"><?= esc_html_e($his_models, "wc-filter") ?></option>
				</select>
				<button name="ua-submit" type="submit" disabled><?= get_option('wc_btn_text') ?></button>
			</form>
		</div>
	</div>
</div>
<?php
	}

	public function wc_filter_footer(){
?>
<script type="text/javascript">

	$ = jQuery;
	$(document).ready(function(){

		$(document).on('change', '#wc-filter-brands', function() {
			
			let brand_name = $(this).val();
			let name =  $("#wc-filter-brands option:selected").attr('data-name');
			let his_brand = $('input[name="his_brand"]').val(name);

			if(brand_name == 'Select Brand'){
				$('#wc-filter-years').prop('disabled', true);
			}
			else{
				$.ajax({
					type: "get",
					url: "<?php echo admin_url('admin-ajax.php'); ?>",
					async:true,
					data: {brand_name:brand_name, action:'get_year_by_brand'},
					success: function(response){
						$('#wc-filter-years').prop('disabled', false);
						$('#wc-filter-years').html(response);
					},
					error: function(err){
					}
				})
			}


		});

		$(document).on('change', '#wc-filter-years', function() {
			
			let year = $(this).val();
			let brand_name = $('#wc-filter-brands').val();
			if(year == 'Select Year'){
				$('#wc-filter-years').prop('disabled', true);
			}
			else{
				$.ajax({
					type: "get",
					url: "<?php echo admin_url('admin-ajax.php'); ?>",
					async:true,
					data: {year:year, brand_name:brand_name, action:'get_model_by_year'},
					success: function(response){
						$('#wc-filter-models').prop('disabled', false);
						$('#wc-filter-models').html(response);					
					},
					error: function(err){

					}
				})
			}


		});

		$(document).on('change', '#wc-filter-models', function(){
			if( $(this).val() != 'Select Model' ){
				$('button[name="ua-submit"]').prop('disabled', false);	
			}else{
				$('button[name="ua-submit"]').prop('disabled', true);
			}					
		})

		$(document).on('click', '.wc-filters-button', function(){
			$(this).next().filter('.wc-mobile-toggler').slideToggle(300);
		})

	});

</script>
<?php
									  }

	public function get_year_by_brand(){

		global $product;
		$sortArr = array();
		$brand_name = $_GET['brand_name'];
		$years = array();

		// The query
		$products = new WP_Query( array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'tax_query'      => array( 
				array(
					'taxonomy'        => 'pa_marka',
					'field'           => 'slug',
					'terms'           =>  $brand_name,
					'operator'        => 'IN',
					'order'           => 'ASC',
					'orderby'         => 'name'
				))
		));

		// The Loop
		if ( $products->have_posts() ):
		echo '<option>';
		echo esc_html_e(get_option('wc_year_text'));
		echo '</option>';
		while ( $products->have_posts() ):
		$products->the_post();
		$cats = get_the_terms( $product->post->ID, 'pa_yil' );
		arsort($cats);		
		foreach($cats as $key => $cat){
// 			echo '<option value="'.$cat->slug.'">'.$cat->name.'</option>';
			array_push($sortArr, '<option value="'.$cat->slug.'">'.$cat->name.'</option>' );
		}
		endwhile;
		arsort($sortArr);
// 		print_r($sortArr);
		foreach($sortArr as $key => $cat){
			echo $cat;
		}
		wp_reset_postdata();
		endif;

		exit;
	}

	public function get_model_by_year(){
		global $product;

		$brand_name = $_GET['brand_name'];
		$year_val = $_GET['year'];
		$years = array();

		// The query
		$products = new WP_Query( array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'tax_query'      => array( 
				array(
					'taxonomy'        => 'pa_marka',
					'field'           => 'slug',
					'terms'           =>  $brand_name,
					'operator'        => 'IN',
				),
				array(
					'taxonomy'        => 'pa_yil',
					'field'           => 'slug',
					'terms'           =>  $year_val,
					'operator'        => 'IN',
				))
		));

		// The Loop
		if ( $products->have_posts() ): 
		echo '<option>';
		echo esc_html_e(get_option('wc_model_text'));
		echo '</option>';
		while ( $products->have_posts() ):
		$products->the_post();
		$cats = get_the_terms( $product->post->ID, 'product_cat' );
		foreach($cats as $key => $cat){
			echo '<option value="'.$cat->slug.'">'.$cat->name.'</option>';
		}
		endwhile;
		wp_reset_postdata();
		endif;

		exit;
	}

}
