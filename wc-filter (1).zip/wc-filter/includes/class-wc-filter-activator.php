<?php

/**
 * Fired during plugin activation
 *
 * @link       https://thewebtechs.com
 * @since      1.0.0
 *
 * @package    Wc_Filter
 * @subpackage Wc_Filter/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wc_Filter
 * @subpackage Wc_Filter/includes
 * @author     The Web Techs <thewebtech8765@gmail.com>
 */
class Wc_Filter_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
