<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://thewebtechs.com
 * @since      1.0.0
 *
 * @package    Wc_Filter
 * @subpackage Wc_Filter/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wc_Filter
 * @subpackage Wc_Filter/admin
 * @author     The Web Techs <thewebtech8765@gmail.com>
 */
class Wc_Filter_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Filter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Filter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wc-filter-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Filter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Filter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-filter-admin.js', array( 'jquery' ), $this->version, false );

	}
	
	public function display_admin_page(){
		add_menu_page(
			'WC Filter Setting',
			'WC Filter Setting',
			'manage_options',
			'wc-filter-setting-admin',
			array($this, 'wc_filter_setting'),
			'',
			6
		);
	}

	public function wc_filter_setting(){

		include plugin_dir_path( __FILE__ ) . 'partials/wc-filter-admin-display.php';
	}
	
	public function wc_filter_settings_group(){
		
		register_setting( 'wc-filter-settings', 'wc_filter_mb_text' );
		register_setting( 'wc-filter-settings', 'wc_btn_text' );
		register_setting( 'wc-filter-settings', 'wc_model_text' );
		register_setting( 'wc-filter-settings', 'wc_year_text' );
		register_setting( 'wc-filter-settings', 'wc_brand_text' );

	}

}
