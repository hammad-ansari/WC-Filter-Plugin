<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://thewebtechs.com
 * @since      1.0.0
 *
 * @package    Wc_Filter
 * @subpackage Wc_Filter/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<h2>WC Filter Settings</h2>
<form method="post" action="options.php">
	<?php settings_fields( 'wc-filter-settings' ); ?>
	<?php do_settings_sections( 'wc-filter-settings' ); 

	?>
	<table class="form-table">
		<tr valign="top">
			<th scope="row">Filter Button Text</th>
			<td><input type="text" name="wc_filter_mb_text" value="<?php echo esc_attr( get_option('wc_filter_mb_text') ); ?>" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">Brand Select Text</th>
			<td><input type="text" name="wc_brand_text" value="<?php echo esc_attr( get_option('wc_brand_text') ); ?>" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">Year Select Text</th>
			<td><input type="text" name="wc_year_text" value="<?php echo esc_attr( get_option('wc_year_text') ); ?>" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">Model Select Text</th>
			<td><input type="text" name="wc_model_text" value="<?php echo esc_attr( get_option('wc_model_text') ); ?>" />
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">Button Text</th>
			<td><input type="text" name="wc_btn_text" value="<?php echo esc_attr( get_option('wc_btn_text') ); ?>" />
			</td>
		</tr>


	</table>

	<?php submit_button(); ?>

</form>